# Eternity cliente backend

## Project setup
```
npm install
```

### Run
```
npm start
```
