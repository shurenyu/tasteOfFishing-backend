global.usersForAppointmentStatus = [];
global.usersForDashboard = [];
global.attendedAppiontments = {};
global.adminToken = null;
global.contractCode = 1;
