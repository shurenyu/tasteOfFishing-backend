module.exports = {
	// BASE_URL: "http://localhost:5000",
	BASE_URL: "http://54.180.210.166:5000",
	SECRET_KEY: "taste-of-fishing-secret-key",
	PENDING_EXPIRATION: 600000,
	GOOGLE_API_KEY: "AIzaSyDDu0SXRJ7mFAl0pVR2PXOm585uiMQcyrg",
	PUSH_API_KEY: "AAAAr37Xwx4:APA91bF9srwQYOxlIKbtDHmiFxSKKTj4Oqr6YeyIuxZSJCiwBueHra0NfKGqLvQK-ZBdYgxFwLzIAmPrnB70-XmMB4v6q8-NbCF_BE0CYB0M85hNtHCvkw6z0oDyc1M-lzBSccEaw8xi"
};
